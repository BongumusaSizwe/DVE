
# Assignment 3

- Answers to 1.1 to 1.2 can be found in "astro_1.1_1.2.ipynb" notebook.
- Answers to 1.3 can be found in "1.3.ipynb" notebook.
- Answers to 2.1 can be found in "2.1 SOM.ipynb" notebook.
- Answers to 2.2 can be found in "micro_array.ipynb" notebook
